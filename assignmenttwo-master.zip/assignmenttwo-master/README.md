COMPX202-20B / COMPX242-20B Assignment 2
========================================

Due on **Friday 31st July at 11:30 pm**.

Java Generics and Testing
-------------------------

**Purpose**: The purposes of this assignment are to get
experience of the important software engineering process of 
testing (manual and unit), and to experiment with
the object-oriented features of Java, including generics.

**Git**: Remember to use Git throughout. Commit regularly with
descriptive messages.  This is especially important if you are
working on lab machines via Horizon as information from your
session will not be saved unless you move it to H: or K:

**Reporting**:  Edit this document to report on your work
and include the updated version in your repository.  
(You will notice that 
IntelliJ 'understands' MarkDown, and will show you this
document in raw form or in formatted form.)

Introduction
------------

A stack is a collection that supports adding elements to only one end
and removing them from the same end (i.e. a first-in-last-out data
structure). Stacks have a wide range of applications in situations where
we want to remember the order of requests and service the most recent
first.  

For this assignment you will implemented a bounded stack
and use it to remember the order of commands given to a text editor
so as to allow command 'undo' and 'redo'. A bounded stack is one that
can only hold a limited number of items.

Using a bounded stack limits memory usage. When in use for do/undo, if 
the stack gets full, commands will have to be dropped when new ones
need to be added.  In undo/redo stacks the usual
convention is to drop the oldest item in the stack - in other words to
keep information on only the most recent commands, thereby limiting the
number of commands that can be undone.

The AssignmentTwo Program
---------------------------

This repository holds an IntelliJ project with a sample Java program.
The idea of the program is that it is part of the source code of a 
text editor.  The structure of the text editor is that it has a class 'Document'
to hold the text being edited, and classes allowing users to enter editing
commands.  The interface of 'Document' allows manipulation of a 'cursor' (current
character position in the text), and insertion or deletion of characters at the cursor position.
Normally we would expect a text editor to have a graphic user interface.  In this
program, the Main class is just a command line program to allow a user to
enter simple editing commands at the keyboard. Command line editors in this style
were typical of the very first personal computer in the 1980's.

This example isn't intended to be a practically useful editor; but just to
have enough functionality to allow us to experiment 'doing' and 'undoing' commands.
For maximum simplicity our implementation of Document allows for just a single line of text.
The editor allows us to edit this line.
The 'cursor' is an integer.  If the line holds 'abcd', cursor position 0 is just before the 'a' at the
start of the line, 1 is between
the 'a' and 'b', 4 is between the 'c' and 'd' and 5 is at the end of the line.

The keyboard commands interpreted by the Main class are entered as lines of text holding a string of one
or two letter commands.

| Command | Action |
|:---|:---|
| `e` | is the exit command |
| `d` | deletes the character following the cursor (if possible) |
| `i c` | is a two character command that inserts the given character ```c``` into the document at the cursor position and advances the cursor |
| `f` | advances the cursor (if possible) without altering the text |
| `b` | moves the cursor left (if possible) without altering the text |

not yet implemented are undo and redo commands

| Command | Action |
|:---|:---|
| `z` | undo last command.  This can be used repeatedly to undo multiple commands |
| `y` | redo the last command that was undone.  This can be used repeatedly |

Here is a sample interaction with the program.  Note that it displays
the current state of the line of text (the document) and current cursor value
at the start, and after each line of commands has been entered.  User input
follows 'Command >' on lines 3, 6, 9 and 12.

```
Document: 
Cursor position 0
Command > ia
Document: a
Cursor position 1
Command > ibicid
Document: abcd
Cursor position 4
Command > bbix
Document: abxcd
Cursor position 3
Command > e
Document: abxcd
Cursor position 3
```

If you examine the program, you will find that the Main program edits the Document
indirectly.  Instead of directly acting on inputs, it instead
creates an object holding details for each command, and asks those objects to 'perform' 
their command.  The objects created are subtypes of the class 'Command'.  The subtypes used
are 'Insert', 'Delete' and 'MoveCursor', all defined in the file 'Command.java'.
Command is an abstract class defined as follows:

````
public abstract class Command {
    protected Document doc;
    public Command(Document pdoc) { doc = pdoc; }
    public abstract boolean canBeDone();
    public abstract void perform();
    public abstract void undo();
}
````

Its constructor saves a reference to the document being edited.  It has a method
'canBeDone' which can be called to see if it is possible to perform the command, 
and methods 'perform' to carry out the editing operation and 'undo'  to reverse
its effect.  In the sample program you are given, commands are just carried out.
The reason for this indirect way of managing commands is to provide a structure
which will allow you to implement undo and redo.  Command objects can be pushed 
onto undo and redo stacks to be reversed and redone on user request.  

Instructions
------------

### Part A: Setup and Manual Testing

1. Fork this repository using the button at the top of the project
    page.

2. Make sure that the visibility of your project is set to Private. (If not:  Settings >
    expand Permissions > Project visibility: Private; Save changes).

3. Clone your new repository to your computer using the Git support built into IntelliJ IDEA.
	
4. Run the 'Main' program.  It will allow interaction in the IntelliJ 'Run' panel. Enter commands
and experiment until you are satisfied that you can operate the program.  Please note that the
program does have some bugs.  It generally works, but sometimes does not quite work correctly.

5. Systematically experiment with the Main program to find its bugs - ie: Manually Test the program.
There are (at least) two separate coding errors.  Your task is to make a reliable test that 
shows the error;  find and fix the coding fault;  and test again to make sure your fix has worked.
You should describe your work in this document in the following section.  Note that errors may
occur in Command.java or in Main.java.

```
Bug 1.  Test case and error behaviour.

> The 'f' command is not working. Suppose when the user is clicking f the cursor position will move forward.

Bug 1.  Code fix

> case 'f': // Move the cursor forward
                          tryNewCommand(new MoveCursor(doc, +2));
                          break;
In main.java added a break line under the case of 'f'

Bug 2.  Test case and error behaviour.

> If you add some random charcater, the last character could not be delete. However, if your cursor position in second last charcater it will work.

Bug 2.  Code fix

> public boolean canBeDone() {
          return doc.getCursorPosition() < doc.getLength();
  
      }
I took up the -1 from the doc.getlength();

````

### Part B: Unit Testing

6. Try running DocumentTest.java. There are three tests and all should pass.
    - IntelliJ IDEA: Right click the file and choose _Run 'DocumentTest'_ (JUnit should already be configured)
	
7.  Add three more useful tests to DocumentTest.  Your tests should have meaningful comments and
all should succeed.

### Part C: Implementing and Testing BoundedStack

In this section you are asked to implement `BoundedStack` as a
generic data structure.  When extending the editor you will use
BoundedStack's of Command's, but for testing your code you will
use BoundedStack's of String's.
There are different ways to implement a stack. You may choose
any way that you like, but you **must not** use any of the Java
collection classes. You may use arrays; if you do, the provided method
_makeArray_ will be useful (Java does not support generic array
creation using `new T[size]` where T is a type parameter).

You should not use casts, e.g. `(String) someVariable`, in any of the
code for this assignment. The method _makeArray_ is exempt from this
requirement.

8.  BoundedStack.java contains a skeleton for you to fill out. Replace the
lines `throw new RuntimeException("... not yet implemented");` with your
own code (but don't change the method signatures). You may add members
as required.

9.  The file BoundedStackTest.java is provided with one test which will fail until
you implement the method being tested.  Write tests to check that your
implementation works correctly.  I suggest using String as the element type for the tests as has
been coded in BoundedStackTest, but
be aware that in Java strings should be compared using
`str1.equals(str2)` rather than `str1 == str2`.


### Part D:  Undo and Redo

10. Using your BoundedStack (but this time as BoundedStack of Command) extend Main.java
to implement an 'undo' and 'redo' stack for commands.  Note: you may need more than
one BoundedStack.

11.  Manually test your implementation of undo and redo.

````
Describe three tests that you performed.

> Answer here.

````
Submitting
----------

Push your changes to your GitLab repository. Ensure that you can see
your changes on GitLab.  It is usually a good idea to clone the repository
back to a new location on your local machine, to check that it uploaded correctly.

Grading
-------

| Weighting | Allocated to |
|:----------:|------|
| 10% | Good repository usage |
| 16% | Part A. Two bugs reported for instruction 5 |
| 10% | Part B. Three tests added to DocumentTest |
| 24% | Part C. Bounded stack implementation |
| 10% | Part C. Bounded stack tests |
| 20% | Part D: Implementing undo and redo |
| 10% | Part D: Manual tests of undo and redo |
