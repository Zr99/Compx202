Assignment One by *Ryan Ling* (*1350127*)
---

# Keywords
* **class** - A plan of the object. The class can be anything such as Car, Head, Chicken. Class represents the set of properties or methods that are commonly use in the object. There are several type of classes such as nested classes, anonymous classes, lambda expression. 
* **extends** - Inheritance can be defined as the process where one class acquires the properties of another. We can inherit the information in a hierarchical order. The class which inherits the properties of other is known as subclass and the class whose properties are inherited is known as superclass. Extends is the keyword used to inherit the properties of a class. 
* **interface** - Interface is a mechanism to achieve abstraction. There can be only abstract methods in the interface, not method body. It is used to achieve abstraction and multiple inheritance. It cannot be instantiated just like the abstract class.
* **private, protected, public** - These are the signatures of the methods. Private is able to use in the class but not outside of the class. Protected is also only can use in the class and can be seen by subclasses or package members. Public is able to use inside and outside of the class.
* **static** - Static are associated with the class itself, not with any particular object created from the class. The value of a static field is the same across all instances of the class. You don’t have to create an object from a class before you can use static methods defined by the class. Therefore, the main method must be static, which means that applications run in a static context by default.

# Concepts
* **Information Hiding** - Information Hiding is a concept that access information should be restricted to reduce the interconnectedness of a system. It also an idea that information should be hidden so that design can be changed without affecting the main part of code. This allows a huge amount flexibility and robustness. Java allows us to control access using keywords. The keywords are public, private and protected.
```
public class BankAcc{
    public int dollars;
}
```

This is a bank account class which has a **PUBLIC** int variable. It will result cannot easily add support for individual cents in the future and unsafe because the method can be access by anywhere in the code. 

```
public class BankAcc{
    private int cents;
    
    public void deposit(int dollars){
        this.dollars += Math.max(0,dollars);
    }
}
```
We now have control over how the state is modified. The variable of cents is set to **private**.

```
public class BankAcc{
    private int cents;
    
    public void deposit(int dollars){
        this.dollars += Math.max(0,dollars);
    }
    
    publoc void deposit(int dollars, int cents){
        this.cents += Math.max(0, 100 * dollars) + Math.max(0, cents);
    }
}
```
This part of codes you can see that I have 2 same name variables that called **deposit** but the implementation will not break the codes. The class is more stable and safe under the implementation of information hiding.

* **Inheritance** - Inheritance is a concept which one object acquires all the properties and behaviors of a parent objects. The concept behind inheritance is that you can create new classes that are built upon existing classes. When you inherit from an existing class, you can reuse methods and fields of the parent class. Inheritance represents the **IS-A relationship** which is also knowns as a parent-child relationship. The syntax of Inheritance you will see in Java is **extends**.
*Single Inheritance* 
```
class Animal{
    void sound(){
        System.out.println("roar");
    }
}

class Lion extends Animal{
    void run(){
        System.out.println("Run Run");
    }
    
}
```

```
class main{
    
    public static void main(String[] args){
        Lion l = new Lion();
        l.sound();
        l.run();
    }
}
```

```
Output:
roar
Run Run
```

In this example, the Lion class inherit to the Animal class. Animal class considers as parent in here. So when it comes to main program, the lion object can access to the method in Animal class. So there is the single inheritance.

* **Polymorphism** - Polymorphism means "many forms", and it occurs when we have many classes that are related to each other by inheritance. The most common way you will see Polymorphism in Object-Oriented Programming occurs when a parent class reference is used to refer to a child class object. All the java object that can pass more than one IS-A test is considered to be polymorphic. There are two types of Polymorphism which are static and dynamic.

*Static Polymorphism:*

``` Class Calculator
class Calculator{
    //method 1
    public int add(int x, int y){ 
        return x + y;
    }
    //method 2
    public int add(double x, int y, int z){
        return int(x) + y + z;
    }
}
```
```Main program
class Computer{
    public static void main(String[] args){
        Calculator cal = new Calculator();
        System.out.println(cal.add(2,3)); // method 1
        System.out.println(cal.add(22,9,1)); //method 2
    }
}
```
In above example, I created 1 Calculator class that can add. The first method takes 2 parameters and second add method is taking 3 parameters. They are all called 'add' method. The  compiler looks at the method signature and decides which method to invoke for a particular method call at compile time. Static polymorphism in Java is achieved by method overloading.

*Dynamic Polymorphism:*
```
class Animal{
    public void run(){
        System.out.println("Run Run Run");
    }
    }
}

class Lion extends Animal{
    public void run(){
        System.out.println("Lion can run!");
    }
}

```

```
class Zoo{
    
    public static void main(String[] args){
        Animal ani = new Lion();
        ani.run(); // will print out Lion can run
        ani = new Animal();
        ani.run(); // will print out Run Run Run
    }
}
```

The first run method is reference to the Animal and the object being referenced is Lion. So when a call to run is made, Java waits until runtime to determine which object is actually pointed to by the reference. In the second run method, the object class is Aniaml. So, the run method of Animal will be called. The method to be called is determined at runtime, this is called dynamic binding.