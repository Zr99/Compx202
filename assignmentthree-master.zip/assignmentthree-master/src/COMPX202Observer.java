public interface COMPX202Observer<TargetType> {
    public void update(TargetType o);
}