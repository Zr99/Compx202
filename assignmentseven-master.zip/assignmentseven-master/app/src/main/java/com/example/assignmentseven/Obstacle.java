package com.example.assignmentseven;

public class Obstacle extends Ball {
    public Obstacle(float diameter,float x,float y,float xSpeed,float ySpeed,int colour){
        super(diameter,x,y,xSpeed,ySpeed,colour);
    }
}
